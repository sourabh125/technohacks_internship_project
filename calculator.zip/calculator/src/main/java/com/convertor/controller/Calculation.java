package com.convertor.controller;

import java.lang.ProcessBuilder.Redirect;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Calculation {

	@RequestMapping(value="calculation", method=RequestMethod.POST)
	public String calculation(@RequestParam(value="binaryno") String binary,Model model)
	{
		
		int count=0;
		int ans=0;
		for(int i=binary.length()-1;i>=0;i--)
		{
			if(binary.charAt(i)=='1')		
				ans+=(Math.pow(2,count));
			else if(binary.charAt(i)!='1' && binary.charAt(i)!='0')
			{	ans=0; break;}
				
			count++;
		}
		model.addAttribute("ans",ans);
		return "convertor";
	}
	
	@RequestMapping(value="convertorpage")
	public String convertorPage()
	{
		return "convertor";
	}
	
}
